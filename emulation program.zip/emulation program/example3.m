%non-repetitive system
clc
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k2=0.5;

T=61;
dt=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A=[1.1 0.12 -0.3 0.4;0.18 0.16 0.1 1.3;1.5 0.1 0.2 0.9;0.7 1.7 0.2 0.6] ;
B=[1.14 0.42 0.843 -0.5965;0.0067 -1.08 0.2578 3;-0.25 0.24 0.239 0.3421;0.4213 0.67 0.078 0.5657];
C=[1 0 1.5 0.33;2 0.02 1.76 0.78;-0.789 0.0478 -1.982 0.6721;0.3402 1.3 1.2 1.76];
det(C)
vrho(A-B*k2*C)

u=zeros(4,T); 
e1=zeros(4,T); 
x1=zeros(4,T); 
y1=zeros(4,T); 
u2=zeros(4,T); 
e2=zeros(4,T);  
x2=zeros(4,T); 
y2=zeros(4,T); 
xd=zeros(4,T);
yd=zeros(4,T);
alpha=zeros(16,T);
for t=1:30
     xd(1,t)=2*(6*t^5*30^(-5)-15*t^4*30^(-4)+10*t^3*30^(-3));
end

for t=31:61
    xd(1,t)=2*(6*(60-t)^5*30^(-5)-15*(60-t)^4*30^(-4)+10*(60-t)^3*30^(-3));
end

for t=1:T
     xd(2,t)=sin(t/30*pi);
     xd(3,t)=cos(t/30*pi);
     xd(4,t)=exp(t/30);
     yd(:,t)=C*xd(:,t);
end
%P-type  control law
x1(:,1)=5*[rand;rand;rand;rand];
y1(:,1)=C*x1(:,1);
e1(:,1)=yd(:,1)-y1(:,1);
for t=1:T-1
    u(:,t)=k2*e1(:,t);
    x1(:,t+1)=A*x1(:,t)+B*u(:,t);
    y1(:,t+1)=C*x1(:,t+1);
    e1(:,t+1)=yd(:,t+1)-y1(:,t+1);
end

%the proposed control law
x2(:,1)=x1(:,1);
y2(:,1)=y1(:,1);
e2(:,1)=e1(:,1);
for t=1:9 
    u2(:,t)=k2*e2(:,t);
    x2(:,t+1)=A*x2(:,t)+B*u2(:,t);
    y2(:,t+1)=C*x2(:,t+1);
    e2(:,t+1)=yd(:,t+1)-y2(:,t+1);  
end


A2=x2(:,2);
A3=x2(:,3);
A4=x2(:,4);
A5=x2(:,5);
A6=x2(:,6);
A7=x2(:,7);
A8=x2(:,8);
A9=x2(:,9);
A10=x2(:,10);
vec1=[A10 A9 A8 A7 A6 A5 A4 A3 zeros(4, 8)];
vec2=[zeros(4, 8) A9 A8 A7 A6 A5 A4 A3 A2];
vec3=[eye(8) -eye(8)];
yeta=[vec1; vec2; vec3];    


for t=10:T-1 
    alpha(:,t)=inv(yeta)*[xd(:,t+1);x2(:,t);zeros(8, 1)];
    u2(:,t)=alpha(1,t)*u2(:,9)+alpha(2,t)*u2(:,8)+alpha(3,t)*u2(:,7)+alpha(4,t)*u2(:,6)+alpha(5,t)*u2(:,5)+alpha(6,t)*u2(:,4)+alpha(7,t)*u2(:,3)+alpha(8,t)*u2(:,2);
    x2(:,t+1)=A*x2(:,t)+B*u2(:,t);
    y2(:,t+1)=C*x2(:,t+1);
    e2(:,t+1)=yd(:,t+1)-y2(:,t+1);
end

figure_FontSize=22;
figure_size=1;
font_size=20;

figure(1)
subplot(221);
t=1:T;
plot((t-1)*dt,y2(1,t),'b',(t-1)*dt,y1(1,t),'r',(t-1)*dt,yd(1,t),'k');
xlabel('time t (s)')
ylabel('y, y_p, y_r');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('y(t)','y_{p}(t)','y_r(t)');
set(h1,'Fontsize',figure_FontSize-5);  
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);

subplot(222);
t=1:T;
plot((t-1)*dt,y2(2,t),'b',(t-1)*dt,y1(2,t),'r',(t-1)*dt,yd(2,t),'k');
xlabel('time t (s)')
ylabel('y, y_p, y_r');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('y(t)','y_{p}(t)','y_r(t)');
set(h1,'Fontsize',figure_FontSize-5);  
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);

subplot(223);
t=1:T;
plot((t-1)*dt,y2(3,t),'b',(t-1)*dt,y1(3,t),'r',(t-1)*dt,yd(3,t),'k');
xlabel('time t (s)')
ylabel('y, y_p, y_r');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('y(t)','y_{p}(t)','y_r(t)');
set(h1,'Fontsize',figure_FontSize-5);  
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);

subplot(224);
t=1:T;
plot((t-1)*dt,y2(4,t),'b',(t-1)*dt,y1(4,t),'r',(t-1)*dt,yd(4,t),'k');
xlabel('time t (s)')
ylabel('y, y_p, y_r');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('y(t)','y_{p}(t)','y_r(t)');
set(h1,'Fontsize',figure_FontSize-5);  
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);

figure(5)
subplot(221);
t=1:T;
plot((t-1)*dt,e2(1,t),'b',(t-1)*dt,e1(1,t),'r');
ylabel('e(t)...e_k(t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('e(t)','e_{p}(t)');
set(h1,'Fontsize',figure_FontSize-5);  
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);

subplot(222);
t=1:T;
plot((t-1)*dt,e2(2,t),'b',(t-1)*dt,e1(2,t),'r');
ylabel('e(t)...e_k(t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('e(t)','e_{p}(t)');
set(h1,'Fontsize',figure_FontSize-5);  
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);

subplot(223);
t=1:T;
plot((t-1)*dt,e2(3,t),'b',(t-1)*dt,e1(3,t),'r');
ylabel('e(t)...e_k(t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('e(t)','e_{p}(t)');
set(h1,'Fontsize',figure_FontSize-5);  
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);

subplot(224);
t=1:T;
plot((t-1)*dt,e2(4,t),'b',(t-1)*dt,e1(4,t),'r');
ylabel('e(t)...e_k(t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('e(t)','e_{p}(t)');
set(h1,'Fontsize',figure_FontSize-5);  
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);

figure(2)
g1=axes('position',[0.1 0.1 0.8 0.8]);
t=1:T;
plot((t-1)*dt,e2(1,t),'r',(t-1)*dt,e2(2,t),'b',(t-1)*dt,e2(3,t),'g');
ylabel('e(t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('e(1,t)','e(2,t)','e(3,t)');
set(h1,'Fontsize',figure_FontSize-5);  
set(gca,'linewidth',figure_size);   
set(get(gca,'Children'),'linewidth',figure_size);  
set(gca,'fontsize',font_size);
set(gca,'fontsize',font_size);
g2=axes('position',[0.3 0.5 0.5 0.3]);
axis(g2);
t=11:T;
plot((t-1)*dt,e2(1,t),'r',(t-1)*dt,e2(2,t),'b',(t-1)*dt,e2(3,t),'g');
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);


figure(3)
subplot(221);
t=1:T;
plot((t-1)*dt,u2(1,t),'r',(t-1)*dt,u(1,t),'b');
ylabel('u(1,t), u_p(1,t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('u(1,t)','u_p(1,t)');
set(h1,'Fontsize',figure_FontSize-5); 
set(gca,'linewidth',figure_size); 
set(get(gca,'Children'),'linewidth',figure_size);  
set(gca,'fontsize',font_size);
set(gca,'fontsize',font_size);

subplot(222);
t=1:T;
plot((t-1)*dt,u2(2,t),'r',(t-1)*dt,u(2,t),'b');
ylabel('u(2,t), u_p(2,t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('u(2,t)','u_p(2,t)');
set(h1,'Fontsize',figure_FontSize-5); 
set(gca,'linewidth',figure_size); 
set(get(gca,'Children'),'linewidth',figure_size);  
set(gca,'fontsize',font_size);

subplot(223);
t=1:T;
plot((t-1)*dt,u2(3,t),'r',(t-1)*dt,u(3,t),'b');
ylabel('u(3,t), u_p(3,t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('u(3,t)','u_p(3,t)');
set(h1,'Fontsize',figure_FontSize-5); 
set(gca,'linewidth',figure_size); 
set(get(gca,'Children'),'linewidth',figure_size);  
set(gca,'fontsize',font_size);

subplot(224);
t=1:T;
plot((t-1)*dt,u2(4,t),'r',(t-1)*dt,u(4,t),'b');
ylabel('u(4,t), u_p(4,t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('u(4,t)','u_p(4,t)');
set(h1,'Fontsize',figure_FontSize-5); 
set(gca,'linewidth',figure_size); 
set(get(gca,'Children'),'linewidth',figure_size);  
set(gca,'fontsize',font_size);

figure(4)
t=1:T-1;
p=plot((t-1)*dt,alpha(1,t),'r',(t-1)*dt,alpha(2,t),'g',(t-1)*dt,alpha(3,t),'b',(t-1)*dt,alpha(4,t),'k',(t-1)*dt,alpha(5,t),'c',(t-1)*dt,alpha(6,t),'m',(t-1)*dt,alpha(7,t),'y',(t-1)*dt,alpha(8,t),'r--',(t-1)*dt,alpha(9,t),'r-.',(t-1)*dt,alpha(10,t),'g-.',(t-1)*dt,alpha(11,t),'b-.',(t-1)*dt,alpha(12,t),'k-.',(t-1)*dt,alpha(13,t),'c-.',(t-1)*dt,alpha(14,t),'m-.',(t-1)*dt,alpha(15,t),'y-.',(t-1)*dt,alpha(16,t),'r:.');
ylabel('\alpha_{3,i}(t), \gamma_{i}(t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);
ah=axes('position',get(gca,'position'),'visible','off');
h1=legend(ah,p(1:8),'\alpha_{3,1}(t)','\alpha_{3,2}(t)','\alpha_{3,3}(t)','\alpha_{3,4}(t)','\alpha_{3,5}(t)','\alpha_{3,6}(t)','\alpha_{3,7}(t)','\alpha_{3,8}(t)');
set(h1,'Fontsize',figure_FontSize);  
ah=axes('position',get(gca,'position'),'visible','off');
h2=legend(ah,p(9:16),'\gamma_{1}(t)','\gamma_{2}(t)','\gamma_{3}(t)','\gamma_{4}(t)','\gamma_{5}(t)','\gamma_{6}(t)','\gamma_{7}(t)','\gamma_{8}(t)');
set(h2,'Fontsize',figure_FontSize);  

