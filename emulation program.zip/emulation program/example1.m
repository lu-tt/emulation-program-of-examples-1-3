%the system matrix A is accurately known
clc
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k1=0.5848;%the gain coefficient

K=4;  %number of iterations
T=401;%running time interval
dt=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%A,B,C are system parameter matrices
A=[0 -0.5996;0.7843 0.5994];
B=[-0.5965 0 0.4213;0.67 1.0780 0.5657];
C=[0 1.01;0.5 0.3;0.2 0.76];
vrho(eye(2)-B*k1*C)
alpha=zeros(2,T);%the parameters of ideal controller 
u=zeros(3,K,T); %PD type controller
e1=zeros(3,K,T); %errors between actual trajectory and the reference trajectory
x1=zeros(2,K,T);%actual state
xd=zeros(2,T);%reference state
y1=zeros(3,K,T);%actual trajectory
yd=zeros(3,T);%reference trajectory
u12=zeros(1,T);%the component of P-type controller in the second iteration
u22=zeros(1,T);
u32=zeros(1,T);
u13=zeros(1,T);%the component of P-type controller in the third iteration
u23=zeros(1,T);
u33=zeros(1,T);

ud=zeros(3,T); %ideal controller
e2=zeros(3,T);  %errors between ideal trajectory and the reference trajectory
x2=zeros(2,T);%ideal state
y2=zeros(3,T);%ideal trajectory


for t=1:401
     xd(1,t)=10*sin(t/200*pi);%the reference state
     xd(2,t)=20*cos(t/200*pi);%the reference state
     yd(:,t)=C*xd(:,t);%the  reference trajectory
end

%define the initial state of the first iteration
x1(1:2,1,1)=[xd(1,1);xd(2,1)];
e1(:,1,1)=C*(xd(:,1)-x1(1:2,1,1));

for t=1:T-1
    u(:,1,t)=k1*e1(:,1,t);
    x1(1:2,1,t+1)=A*x1(1:2,1,t)+B*u(:,1,t);
    y1(:,1,t+1)=C*x1(1:2,1,t+1);
    e1(:,1,t+1)=C*(xd(:,t+1)-x1(1:2,1,t+1));
end


for k=1:K-1 %k represents iteration axis
    x1(1:2,k+1,1)=[xd(1,1);xd(2,1)];
    y1(:,k+1,1)=C*x1(1:2,k+1,1);
    e1(:,k+1,1)=C*(xd(:,1)-x1(1:2,k+1,1));
    for t=1:T-1 %t represents the time axis
        if t==1
            u(:,k+1,t)=k1*e1(:,k,t+1);
            x1(1:2,k+1,t+1)=A*x1(1:2,k+1,t)+B*u(:,k+1,t);
            y1(:,k+1,t+1)=C*x1(1:2,k+1,t+1);
            e1(:,k+1,t+1)=C*(xd(:,t+1)-x1(1:2,k+1,t+1));
        else
            u(:,k+1,t)=u(:,k,t)+k1*e1(:,k,t+1);
            x1(1:2,k+1,t+1)=A*x1(1:2,k+1,t)+B*u(:,k+1,t);
            y1(:,k+1,t+1)=C*x1(1:2,k+1,t+1);
            e1(:,k+1,t+1)=C*(xd(:,t+1)-x1(1:2,k+1,t+1));
        end
    end   
end

x2(1:2,1)=[xd(1,1);xd(2,1)];
y2(:,1)=C*x2(1:2,1);
e2(:,1)=C*(xd(:,1)-x2(1:2,1));
for t=1:T-1
     M=[x1(1:2,2,t+1)-A*x1(1:2,2,t) x1(1:2,3,t+1)-A*x1(1:2,3,t)];
     alpha(:,t)=inv(M)*(xd(:,t+1)-A*xd(:,t));
     ud(:,t)=alpha(1,t)*u(:,2,t)+alpha(2,t)*u(:,3,t);
     x2(1:2,t+1)=A*x2(1:2,t)+B*ud(:,t);
     y2(:,t+1)=C*x2(1:2,t+1);
     e2(:,t+1)=C*(xd(:,t+1)-x2(1:2,t+1));

     u12(1,t)=u(1,2,t);
     u22(1,t)=u(2,2,t);
     u32(1,t)=u(3,2,t);
     u13(1,t)=u(1,3,t);
     u23(1,t)=u(2,3,t);
     u33(1,t)=u(3,3,t);
 end

figure_FontSize=22;
figure_size=1;
font_size=20;

figure(1)
t=1:T-1;
p=plot((t-1)*dt,y2(1,t),'r-.',(t-1)*dt,y2(2,t),'r',(t-1)*dt,yd(1,t),'b-.',(t-1)*dt,yd(2,t),'b');
xlabel('time t (s)')
ylabel('y_{1,d}(t),  y_r(t)');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
set(gca,'linewidth',figure_size); 
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);
h1=legend(p(1:2),'y_{1, d}(1,t)','y_{1, d}(2,t)');
set(h1,'Fontsize',figure_FontSize); 
ah=axes('position',get(gca,'position'),'visible','off');
h2=legend(ah,p(3:4),'y_{r}(1,t)','y_{r}(2,t)');
set(h2,'Fontsize',figure_FontSize); 
ah1=axes('position',get(gca,'position'),'visible','off');
set(gca,'linewidth',figure_size); 
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);

figure(2)
t=1:T-1;
q=plot((t-1)*dt,ud(1,t),'r:',(t-1)*dt,ud(2,t),'r',(t-1)*dt,ud(3,t),'r-.',...
    (t-1)*dt,u12(1,t),'g:',(t-1)*dt,u22(1,t),'g',(t-1)*dt,u32(1,t),'g-.',...
    (t-1)*dt,u13(1,t),'b:',(t-1)*dt,u23(1,t),'b',(t-1)*dt,u33(1,t),'b-.');
xlabel('time t (s)')
ylabel('u_k(t), u_{1,d}(t)');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
set(gca,'linewidth',figure_size); 
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);
h1=legend(q(1:3),'u_{1,d}(1,t)','u_{1,d}(2,t)','u_{1,d}(3,t)');
set(h1,'Fontsize',figure_FontSize); 
ah=axes('position',get(gca,'position'),'visible','off');
h2=legend(ah,q(4:6),'u_{2}(1,t)','u_{2}(2,t)','u_{2}(3,t)');
set(h2,'Fontsize',figure_FontSize);  
ah=axes('position',get(gca,'position'),'visible','off');
h3=legend(ah,q(7:9),'u_{3}(1,t)','u_{3}(2,t)','u_{3}(3,t)');
set(h3,'Fontsize',figure_FontSize); 

figure(3)
t=1:T-1;
plot((t-1)*dt,e2(1,t),'r',(t-1)*dt,e2(2,t),'b');
ylabel('e_{1,d}(t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('e_{1,d}(1,t)','e_{1,d}(2,t)');
set(h1,'Fontsize',figure_FontSize); 
set(gca,'linewidth',figure_size); 
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);

figure(4)
t=1:T-1;
plot((t-1)*dt,alpha(1,t),'r',(t-1)*dt,alpha(2,t),'b');
ylabel('\alpha_{1,1}(t), \alpha_{1,2}(t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('\alpha_{1,1}(t)','\alpha_{1,2}(t)');
set(h1,'Fontsize',figure_FontSize); 
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);


