%the system matrix A is unknown
clc
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

K=10;  
T=101;
dt=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A=[0.1490 0.78 -0.3453; -0.7100 0.902 0.1212;1.504 0.1976 0.2534];
B=[0.1456  0.843 0.843;0.2578  0.239 0.2578;-0.25 0.24 0.239];
C=[-0.234 0.789 1.534;0.478 0.982 0.76;-0.789 0.478 -0.982];
k2=inv(C*B)*0.7;
k1=inv(B)*0.9*A*inv(C);
vrho(eye(3)-C*B*k2)
vrho(A)
alpha=zeros(12,T);
u=zeros(3,K,T); 
e1=zeros(3,K,T); 
e11=zeros(K,T);  
e12=zeros(K,T);  
e13=zeros(K,T);  
x1=zeros(3,K,T);
xd=zeros(3,T);
y1=zeros(3,K,T);
yd=zeros(3,T);

u2=zeros(3,T); 
e2=zeros(3,T); 
x2=zeros(3,T);
y2=zeros(3,T);

for t=1:T
     xd(1,t)=20-20*cos(t/50*pi);
     xd(2,t)=6*(t/50)^5-15*(t/50)^4+10*(t/50)^3;
     xd(3,t)=exp(t/50);
     yd(:,t)=C*xd(:,t);
end

x1(:,1,1)=[rand;rand;rand];
e1(:,1,1)=C*(xd(:,1)-x1(:,1,1));

for t=1:T-1
    u(:,1,t)=k1*e1(:,1,t);
    x1(:,1,t+1)=A*x1(:,1,t)+B*u(:,1,t);
    y1(:,1,t+1)=C*x1(:,1,t+1);
    e1(:,1,t+1)=C*(xd(:,t+1)-x1(:,1,t+1));
    e11(1,t+1)=e1(1,1,t+1);
    e12(1,t+1)=e1(2,1,t+1);
    e13(1,t+1)=e1(3,1,t+1);
end


for k=1:K-1 
    x1(:,k+1,1)=[rand;rand;rand];
    y1(:,k+1,1)=C*x1(:,k+1,1);
    e1(:,k+1,1)=C*(xd(:,1)-x1(:,k+1,1));
    for t=1:T-1 
        u(:,k+1,t)=u(:,k,t)+k2*e1(:,k,t+1)+k1*e1(:,k+1,t);
        x1(:,k+1,t+1)=A*x1(:,k+1,t)+B*u(:,k+1,t);
        y1(:,k+1,t+1)=C*x1(:,k+1,t+1);
        e1(:,k+1,t+1)=C*(xd(:,t+1)-x1(:,k+1,t+1));
        e11(k+1,t+1)=e1(1,k+1,t+1);
        e12(k+1,t+1)=e1(2,k+1,t+1);
        e13(k+1,t+1)=e1(3,k+1,t+1);
    end        
end


x2(:,1)=[rand;rand;rand];
y2(:,1)=C*x2(:,1);
e2(:,1)=C*(xd(:,1)-x2(:,1));
for t=1:T-1
    A1=x1(:,K-5,t+1);
    A2=x1(:,K-4,t+1);
    A3=x1(:,K-3,t+1);
    A4=x1(:,K-2,t+1);
    A5=x1(:,K-1,t+1);
    A6=x1(:,K,t+1);
    A7=x1(:,K-5,t);
    A8=x1(:,K-4,t);
    A9=x1(:,K-3,t);
    A10=x1(:,K-2,t);
    A11=x1(:,K-1,t);
    A12=x1(:,K,t);
    vec1=[A1 A2 A3 A4 A5 A6 zeros(3, 6)];
    vec2=[zeros(3, 6) A7 A8 A9 A10 A11 A12];
    vec3=[eye(6) -eye(6)];
    yeta=[vec1; vec2; vec3];
    alpha(:,t)=inv(yeta)*[xd(:,t+1);x2(:,t);zeros(6, 1)];
    u2(:,t)=alpha(1,t)*u(:,K-5,t)+alpha(2,t)*u(:,K-4,t)+alpha(3,t)*u(:,K-3,t)+alpha(4,t)*u(:,K-2,t)+alpha(5,t)*u(:,K-1,t)+alpha(6,t)*u(:,K,t);
    x2(:,t+1)=A*x2(:,t)+B*u2(:,t);
    y2(:,t+1)=C*x2(:,t+1);
    e2(:,t+1)=C*(xd(:,t+1)-x2(:,t+1));
 end

figure_FontSize=22;
figure_size=1;
font_size=20;

figure(2)
t=1:T-1;
p=plot((t-1)*dt,u2(1,t),'r',(t-1)*dt,u2(2,t),'b',(t-1)*dt,u2(3,t),'g');
xlabel('time t (s)');
ylabel('u_{2,d}');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
set(gca,'linewidth',figure_size); 
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);
h1=legend('u_{2, d}(1,t)','u_{2, d}(2,t)','u_{2, d}(3,t)');
set(h1,'Fontsize',figure_FontSize); 
set(gca,'linewidth',figure_size);
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);

figure(3)
t=1:T-1;
plot((t-1)*dt,y2(1,t),'r',(t-1)*dt,y2(2,t),'b',(t-1)*dt,y2(3,t),'g',(t-1)*dt,yd(1,t),'r-.',(t-1)*dt,yd(2,t),'b-.',(t-1)*dt,yd(3,t),'g-.');
ylabel('y_{2,d}(t), y_{r}(t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('y_{2,d}(1,t)','y_{2,d}(2,t)','y_{2,d}(3,t)','y_{r}(1,t)','y_{r}(2,t)','y_{r}(3,t)');
set(h1,'Fontsize',figure_FontSize); 
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);


figure(4)
subplot(121);
t=1:T-1;
plot((t-1)*dt,e11(K,t),'r',(t-1)*dt,e12(K,t),'b',(t-1)*dt,e13(K,t),'g');
ylabel('e_{k}(t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('e_{10}(1,t)','e_{10}(2,t)','e_{10}(3,t)');
set(h1,'Fontsize',figure_FontSize); 
set(gca,'linewidth',figure_size); 
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);
subplot(122);
t=1:T-1;
plot((t-1)*dt,e2(1,t),'r',(t-1)*dt,e2(2,t),'b',(t-1)*dt,e2(3,t),'g');
ylabel('e_{2,d}(t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
h1=legend('e_{2,d}(1,t)','e_{2,d}(2,t)','e_{2,d}(3,t)');
set(h1,'Fontsize',figure_FontSize); 
set(gca,'linewidth',figure_size); 
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);
g3=axes('position',[0.65 0.2 0.2 0.3]);
axis(g3);
t=2:100;
plot((t-1)*dt,e2(1,t),'r',(t-1)*dt,e2(2,t),'b',(t-1)*dt,e2(3,t),'g');
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);

figure(7)
t=1:T-1;
p=plot((t-1)*dt,alpha(1,t),'r',(t-1)*dt,alpha(2,t),'g',(t-1)*dt,alpha(3,t),'b',(t-1)*dt,alpha(4,t),'k',(t-1)*dt,alpha(5,t),'c',(t-1)*dt,alpha(6,t),'m',...
    (t-1)*dt,alpha(7,t),'r-.',(t-1)*dt,alpha(8,t),'g-.',(t-1)*dt,alpha(9,t),'b-.',(t-1)*dt,alpha(10,t),'k-.',(t-1)*dt,alpha(11,t),'c-.',(t-1)*dt,alpha(12,t),'m-.');
ylabel('\alpha_{2,i}(t), \beta_{i}(t)');
xlabel('time t');
set(get(gca,'XLabel'),'FontSize',figure_FontSize);
set(get(gca,'YLabel'),'FontSize',figure_FontSize); 
set(gca,'linewidth',figure_size);
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);
ah=axes('position',get(gca,'position'),'visible','off');
h1=legend(ah,p(1:6),'\alpha_{2,1}(t)','\alpha_{2,2}(t)','\alpha_{2,3}(t)','\alpha_{2,4}(t)','\alpha_{2,5}(t)','\alpha_{2,6}(t)');
set(h1,'Fontsize',figure_FontSize);  
ah=axes('position',get(gca,'position'),'visible','off');
h2=legend(ah,p(7:12),'\beta_{1}(t)','\beta_{2}(t)','\beta_{3}(t)','\beta_{4}(t)','\beta_{5}(t)','\beta_{6}(t)');
set(h2,'Fontsize',figure_FontSize);  
g3=axes('position',[0.3 0.25 0.4 0.2]);
axis(g3);
t=20:100;
plot((t-1)*dt,alpha(1,t),'r',(t-1)*dt,alpha(2,t),'g',(t-1)*dt,alpha(3,t),'b',(t-1)*dt,alpha(4,t),'k',(t-1)*dt,alpha(5,t),'c',(t-1)*dt,alpha(6,t),'m',...
    (t-1)*dt,alpha(7,t),'r-.',(t-1)*dt,alpha(8,t),'g-.',(t-1)*dt,alpha(9,t),'b-.',(t-1)*dt,alpha(10,t),'k-.',(t-1)*dt,alpha(11,t),'c-.',(t-1)*dt,alpha(12,t),'m-.');
xlim([20,80]);
set(gca,'linewidth',figure_size);  
set(get(gca,'Children'),'linewidth',figure_size); 
set(gca,'fontsize',font_size);
